//
//  PlaceDetail.swift
//  GetGoingClass
//
//  Created by Caner Adil IRFANOGLU on 2/5/19.
//  Copyright © 2019 SMU. All rights reserved.
//

import Foundation

class PlaceDetail {
    var id: String
    var name: String?

    var placeid: String?
    var phoneNo: String?
    var website: String?
    
    init?(json: [String: Any]) {
        guard let id = json["id"] as? String else { return nil }
        self.id = id
        
        self.name = json["name"] as? String
        self.placeid = json["place_id"] as? String
        self.phoneNo = json["formatted_phone_number"] as? String
        self.website = json["website"] as? String
    }
}
