//
//  PlaceDetails.swift
//  GetGoingClass
//
//  Created by Alla Bondarenko on 2019-01-23.
//  Copyright © 2019 SMU. All rights reserved.
//

import Foundation

class PlaceDetails: NSObject, NSCoding {
    struct PropertyKey {
        static let idKey = "id"
        static let nameKey = "name"
        static let vicinityKey = "vicinity"
        static let formattedAdressKey = "formattedAddress"
        static var ratingKey = "rating"
        static let iconKey = "icon"
        static let placeidKey = "placeid"
    }
    
    // MARK : - NSCoding
    func encode(with aCoder: NSCoder) {
        aCoder.encode(id, forKey: PropertyKey.idKey)
        aCoder.encode(name, forKey: PropertyKey.nameKey)
        aCoder.encode(vicinity, forKey: PropertyKey.vicinityKey)
        aCoder.encode(formattedAddress, forKey: PropertyKey.formattedAdressKey)
        if let rating = rating { aCoder.encode(rating, forKey: PropertyKey.ratingKey)}
        aCoder.encode(icon, forKey: PropertyKey.iconKey)
        aCoder.encode(placeid, forKey: PropertyKey.placeidKey)
    }
    
    // MARK : - Initializors
    required convenience init?(coder aDecoder: NSCoder) {
        let id =  aDecoder.decodeObject(forKey: PropertyKey.idKey) as? String ?? ""
        let name = aDecoder.decodeObject(forKey: PropertyKey.nameKey) as? String
        let vicinity = aDecoder.decodeObject(forKey: PropertyKey.vicinityKey) as? String
        let formatedAddress = aDecoder.decodeObject(forKey: PropertyKey.formattedAdressKey) as? String
        let rating = aDecoder.decodeDouble(forKey: PropertyKey.ratingKey)
        let icon = aDecoder.decodeObject(forKey: PropertyKey.iconKey) as? String
        let placeid = aDecoder.decodeObject(forKey: PropertyKey.placeidKey) as? String
        self.init(id: id, name: name, vicinity: vicinity, formatedAddress: formatedAddress, rating: rating, icon: icon, placeid: placeid)
    }

    init(id: String, name: String?, vicinity: String?, formatedAddress: String?, rating: Double?, icon: String?, placeid: String?) {
        self.id = id
        self.name = name
        self.vicinity = vicinity
        self.formattedAddress = formatedAddress
        self.rating = rating
        self.icon = icon
        self.placeid = placeid
        
    }
    
    // MARK: - Variables
    var id: String
    var name: String?
    var vicinity: String?
    var formattedAddress: String?
    var rating: Double?
    var icon: String?
    var address: String? {
        return formattedAddress ?? vicinity
    }
    var placeid: String?

    init?(json: [String: Any]) {
        guard let id = json["id"] as? String else { return nil }
        self.id = id

        self.name = json["name"] as? String
        self.vicinity = json["vicinity"] as? String
        self.formattedAddress = json["formatted_address"] as? String
        self.rating = json["rating"] as? Double
        self.icon = json["icon"] as? String
        self.placeid = json["place_id"] as? String
    }
}
