//
//  FiltersViewController.swift
//  GetGoingClass
//
//  Created by Caner Adil IRFANOGLU on 2/4/19.
//  Copyright © 2019 SMU. All rights reserved.
//

import UIKit

enum RankBy {
    case prominence, distance
    
    func description() ->  String {
        switch self {
        case .distance:
            return String(describing: self).capitalized
        case .prominence:
            return String(describing: self).capitalized
        }
    }
}

class FiltersViewController: UIViewController {

    @IBOutlet weak var isOpenNow: UISwitch!
    @IBOutlet weak var radiusSlider: UISlider!
    @IBOutlet weak var rankByLabel: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    var rankByDictionary: [RankBy] = [.prominence, .distance]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pickerView.isHidden = true
        rankByLabel.isUserInteractionEnabled = true
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(rankByLabelTapped))
        tapGestureRecognizer.numberOfTapsRequired = 2
        rankByLabel.addGestureRecognizer(tapGestureRecognizer)
        pickerView.delegate = self
        
    }
    
    @objc func rankByLabelTapped() {
        print("Lable was tapped")
        pickerView.isHidden = !pickerView.isHidden
    }
    
    // MARK: - IBActions
    @IBAction func closeButtonAction(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func radiusSliderChangedValue(_ sender: UISlider) {
        print("slider value changed to \(sender.value) int \(Int(sender.value))")
    }
    
    @IBAction func switchValueChanged(_ sender: UISwitch) {
        print("Switch vlaue changed to \(sender.isOn)")
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension FiltersViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return rankByDictionary.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return rankByDictionary[row].description()
        
    }
}
