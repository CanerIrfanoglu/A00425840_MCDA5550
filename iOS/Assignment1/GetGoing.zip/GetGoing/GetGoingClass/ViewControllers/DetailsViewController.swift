//
//  DetailsViewController.swift
//  GetGoingClass
//
//  Created by Caner Adil IRFANOGLU on 2/5/19.
//  Copyright © 2019 SMU. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    
    @IBOutlet weak var websiteLabel: UILabel!
    
    
    
    var places: [PlaceDetail]!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        let place = places[0]
        titleLabel.text = place.name
        websiteLabel.text = place.website
        phoneLabel.text = place.phoneNo
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
