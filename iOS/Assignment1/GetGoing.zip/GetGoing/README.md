# GetGoing

## Obtain API Key 
https://console.developers.google.com/apis/dashboard

## Documentation available 
https://developers.google.com/places/web-service/search?authuser=0#PlaceSearchRequests

## FoodTracker App on Apple Developer website
https://developer.apple.com/library/archive/referencelibrary/GettingStarted/DevelopiOSAppsSwift/BuildABasicUI.html#//apple_ref/doc/uid/TP40015214-CH5-SW1

## Feedback
https://remoteretro.io/retro/c80a2ef3-8ba4-47a5-8dd9-d9939c3bcedd
