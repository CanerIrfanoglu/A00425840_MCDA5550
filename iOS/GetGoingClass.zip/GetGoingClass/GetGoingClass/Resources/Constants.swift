//
//  Constants.swift
//  GetGoingClass
//
//  Created by Nawaz Hussain on 2019-01-21.
//  Copyright © 2019 SMU. All rights reserved.
//

import Foundation

class Constants {
    
    static let apiKey = "AIzaSyBvhQXkyk8pAT23Vok17WPZE7uIivpgK0w"
    
    static let scheme = "https"
    static let host = "maps.googleapis.com"
    static let textPlaceSearch = "/maps/api/place/textsearch/json"
    
}
