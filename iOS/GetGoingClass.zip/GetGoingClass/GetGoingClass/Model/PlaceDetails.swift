//
//  PlaceDetails.swift
//  GetGoingClass
//
//  Created by Caner Adil IRFANOGLU on 1/23/19.
//  Copyright © 2019 SMU. All rights reserved.
//

import Foundation

class PlaceDetails{
    var id: String?
    var name: String?
    var vicinity: String?
    var formattedAddress: String?
    var icon: String?
    var rating: Double?
    
    var address: String? {
        return formattedAddress ?? vicinity
    }
    
    init?(json: [String: Any]) {
        guard let id = json["id"]  as? String else { return nil }
        self.id = id
        
        self.name = json["name"] as? String
        self.vicinity = json["vicinity"] as? String
        self.formattedAddress = json["formatted_address"] as? String
        self.rating = json["rating"] as? Double
        self.icon = json["icon"] as? String

    }
}
