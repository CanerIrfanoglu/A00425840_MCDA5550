//
//  APIParser.swift
//  GetGoingClass
//
//  Created by Caner Adil IRFANOGLU on 1/23/19.
//  Copyright © 2019 SMU. All rights reserved.
//

import Foundation

class APIParser {
    class func parserNearbySearchResults(jsonObj: [String : Any]) -> [PlaceDetails]{
        //array of results, initialized as empty
        var places : [PlaceDetails] = []
        
        if let results = jsonObj["results"] as? [[String: Any]] {
            results.forEach { (result) in
                if let place = PlaceDetails(json: result) {
                    places.append(place)
                }
            }
        }
        return places
    }
}
